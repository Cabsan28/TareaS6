﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Xamarin.Forms;
using TareaSemana6.Models;

namespace TareaSemana6.ViewModel
{
    public class ViewModelCalculadora : INotifyPropertyChanged
    {
        double num1;
        double num2;
        string resultado_operacion;
        double total;
      
        public ViewModelCalculadora()
        {
            EjecutarOperacion = new Command((boton_action) =>
            {
                Operacion op = new Operacion()
                {
                    num1 = this.num1,
                    num2 = this.num2
                };

                if (boton_action.ToString() == "1")
                {
                    Total = op.sumar();
                }
                else if (boton_action.ToString() == "2")
                {
                    Total = op.restar();
                }
                else if (boton_action.ToString() == "3")
                {
                    Total = op.multiplicacion();
                }
                else if (boton_action.ToString() == "4")
                {
                    Total = op.division();
                }

                var arg = new PropertyChangedEventArgs(nameof(Total));
                PropertyChanged?.Invoke(this, arg);

                Resultado_Operacion = $"{op.ToString()} {Total}" ;



            });

        }


        public string Resultado_Operacion
        {
            get => resultado_operacion; set
            {
                resultado_operacion = value;
                var arg = new PropertyChangedEventArgs(nameof(Resultado_Operacion));
                PropertyChanged?.Invoke(this, arg);
            }
        }

        public double Total
        {
            get => total;
            set
            {
                total = value;
                var arg = new PropertyChangedEventArgs(nameof(Total));
                PropertyChanged?.Invoke(this, arg);
            }
        }


        public double Num1
        {
            get => num1;
            set
            {
                num1 = value;
                var arg = new PropertyChangedEventArgs(nameof(Num1));
                PropertyChanged?.Invoke(this, arg);
            }
        }

        public double Num2
        {
            get => num2;
            set
            {
                num2 = value;
                var arg = new PropertyChangedEventArgs(nameof(Num2));
                PropertyChanged?.Invoke(this, arg);
            }
        }

        public Command EjecutarOperacion { get; }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}

