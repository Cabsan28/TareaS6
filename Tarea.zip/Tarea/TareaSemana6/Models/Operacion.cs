﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TareaSemana6.Models
{
    public class Operacion
    {
        public double num1 { get; set; }
        public double num2 { get; set; }


        public double sumar()
        {
            return num1 + num2;
        }

        public double restar()
        {
            return num1 - num2;
        }

        public double multiplicacion()
        {
            return num1 * num2;
        }

        public double division()
        {
            return num1 / num2; 
        }

        public override string ToString()
        {
            return $"El total de la operación es: ";
        }

    }
}
